export default function NotFound() {
    return (
        <div>
            <h2>Ini 404! Post</h2>
        </div>
    );
}
