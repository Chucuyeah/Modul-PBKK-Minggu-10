const Loading = () => {
    return (
        <>
            <h2>Ini Loading</h2>
        </>
    )
}
export default Loading;
