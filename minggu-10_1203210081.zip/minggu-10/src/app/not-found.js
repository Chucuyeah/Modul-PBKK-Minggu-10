export default function NotFound() {
    return (
        <div>
            <h2>Ini 404! Global</h2>
        </div>
    );
}
