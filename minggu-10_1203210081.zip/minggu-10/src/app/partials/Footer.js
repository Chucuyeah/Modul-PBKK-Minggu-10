const Footer = () => {
    return (
        <footer className="w-full bg-gray-500 py-8 p-4 text-white">
            <h1>Myblog@2023</h1>
        </footer>
    );
};
export default Footer;
