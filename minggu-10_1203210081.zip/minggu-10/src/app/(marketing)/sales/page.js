export default function Page() {
    return (
        <div>
            <h1>Ini Halaman Sales</h1>
        </div>
    );
}
